"use client"

import { useState } from "react"
import Link from "next/link"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft, Trophy } from "lucide-react"

const formSchema = z.object({
  firstName: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres." }),
  lastName: z.string().min(2, { message: "Sobrenome deve ter pelo menos 2 caracteres." }),
  email: z.string().email({ message: "Por favor, insira um endereço de e-mail válido." }),
  phone: z.string().min(10, { message: "Por favor, insira um número de telefone válido." }),
  dateOfBirth: z.string().min(1, { message: "Data de nascimento é obrigatória." }),
  gender: z.enum(["male", "female"], { required_error: "Por favor, selecione um gênero." }),
  modality: z.string({ required_error: "Por favor, selecione uma modalidade." }),
  category: z.string({ required_error: "Por favor, selecione uma categoria." }),
  weightClass: z.string({ required_error: "Por favor, selecione uma categoria de peso." }),
  beltRank: z.string({ required_error: "Por favor, selecione uma graduação." }),
  dojoName: z.string().optional(),
  coachName: z.string().optional(),
  yearsExperience: z.string().min(1, { message: "Anos de experiência é obrigatório." }),
  previousTournaments: z.string().optional(),
  medicalConditions: z.string().optional(),
  emergencyContactName: z.string().min(2, { message: "Nome do contato de emergência é obrigatório." }),
  emergencyContactPhone: z
    .string()
    .min(10, { message: "Por favor, insira um número de telefone válido para o contato de emergência." }),
  termsAccepted: z.literal(true, {
    errorMap: () => ({ message: "Você deve aceitar os termos e condições." }),
  }),
})

export default function RegisterPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      dateOfBirth: "",
      gender: undefined,
      modality: "",
      category: "",
      weightClass: "",
      beltRank: "",
      dojoName: "",
      coachName: "",
      yearsExperience: "",
      previousTournaments: "",
      medicalConditions: "",
      emergencyContactName: "",
      emergencyContactPhone: "",
      termsAccepted: false,
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      console.log(values)
      setIsSubmitting(false)
      setIsSuccess(true)
    }, 1500)
  }

  if (isSuccess) {
    return (
      <div className="container mx-auto px-4 py-12 bg-gray-950 text-gray-200">
        <Card className="max-w-2xl mx-auto bg-gray-900 border-gray-800">
          <CardHeader className="text-center">
            <Trophy className="h-12 w-12 text-red-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">Inscrição Realizada com Sucesso!</CardTitle>
            <CardDescription>Obrigado por se inscrever no Campeonato de Lutas 2025.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="mb-6">
              Sua inscrição foi enviada com sucesso. Você receberá um e-mail de confirmação em breve com detalhes
              adicionais.
            </p>
            <p className="mb-6">
              Certifique-se de trazer seu documento de identidade e qualquer equipamento necessário no dia do evento.
            </p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button asChild>
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar para a Página Inicial
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12 bg-gray-950 text-gray-200">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="text-red-500 hover:text-red-400 flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Voltar para a Página Inicial
          </Link>
        </div>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-2xl">Inscrição para o Campeonato</CardTitle>
            <CardDescription>
              Preencha o formulário abaixo para se inscrever no Campeonato de Lutas 2025.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Informações Pessoais</h3>

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome</FormLabel>
                          <FormControl>
                            <Input placeholder="João" {...field} className="bg-gray-800 border-gray-700" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sobrenome</FormLabel>
                          <FormControl>
                            <Input placeholder="Silva" {...field} className="bg-gray-800 border-gray-700" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="joao.silva@exemplo.com"
                              {...field}
                              className="bg-gray-800 border-gray-700"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Telefone</FormLabel>
                          <FormControl>
                            <Input placeholder="(11) 98765-4321" {...field} className="bg-gray-800 border-gray-700" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="dateOfBirth"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Data de Nascimento</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} className="bg-gray-800 border-gray-700" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Gênero</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex space-x-4"
                            >
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <RadioGroupItem value="male" />
                                </FormControl>
                                <FormLabel className="font-normal">Masculino</FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-2">
                                <FormControl>
                                  <RadioGroupItem value="female" />
                                </FormControl>
                                <FormLabel className="font-normal">Feminino</FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Informações do Campeonato</h3>

                  <FormField
                    control={form.control}
                    name="modality"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Modalidade</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-800 border-gray-700">
                              <SelectValue placeholder="Selecione a modalidade" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            <SelectItem value="jiujitsu">Jiu-jitsu</SelectItem>
                            <SelectItem value="judo">Judô</SelectItem>
                            <SelectItem value="taekwondo">Taekwondo</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria de Idade</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gray-800 border-gray-700">
                                <SelectValue placeholder="Selecione a categoria" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              <SelectItem value="infantil">Infantil (até 12 anos)</SelectItem>
                              <SelectItem value="juvenil">Juvenil (13-17 anos)</SelectItem>
                              <SelectItem value="adulto">Adulto (18-40 anos)</SelectItem>
                              <SelectItem value="master">Master (acima de 40 anos)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="weightClass"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria de Peso</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gray-800 border-gray-700">
                                <SelectValue placeholder="Selecione a categoria de peso" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              <SelectItem value="super-leve">Super Leve (até 57 kg)</SelectItem>
                              <SelectItem value="leve">Leve (57-64 kg)</SelectItem>
                              <SelectItem value="medio">Médio (64-70 kg)</SelectItem>
                              <SelectItem value="meio-pesado">Meio-Pesado (70-77 kg)</SelectItem>
                              <SelectItem value="pesado">Pesado (77-84 kg)</SelectItem>
                              <SelectItem value="super-pesado">Super Pesado (acima de 84 kg)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="beltRank"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Graduação</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-800 border-gray-700">
                              <SelectValue placeholder="Selecione a graduação" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            <SelectItem value="iniciante">Iniciante (Branca/Amarela)</SelectItem>
                            <SelectItem value="intermediario">Intermediário (Laranja/Verde)</SelectItem>
                            <SelectItem value="avancado">Avançado (Azul/Roxa)</SelectItem>
                            <SelectItem value="expert">Expert (Marrom/Preta)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="dojoName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome do Dojo/Academia</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Digite o nome do dojo ou academia"
                              {...field}
                              className="bg-gray-800 border-gray-700"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="coachName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome do Treinador/Sensei</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Digite o nome do treinador ou sensei"
                              {...field}
                              className="bg-gray-800 border-gray-700"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="yearsExperience"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Anos de Experiência</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="0"
                            placeholder="Digite os anos de experiência"
                            {...field}
                            className="bg-gray-800 border-gray-700"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="previousTournaments"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Experiência em Torneios Anteriores</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Liste quaisquer torneios anteriores em que você participou e conquistas"
                            className="resize-none bg-gray-800 border-gray-700"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Informações Médicas e de Emergência</h3>

                  <FormField
                    control={form.control}
                    name="medicalConditions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Condições Médicas</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Liste quaisquer condições médicas, alergias ou lesões que a equipe do evento deve estar ciente"
                            className="resize-none bg-gray-800 border-gray-700"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription className="text-gray-400">
                          Essas informações serão mantidas confidenciais e usadas apenas em caso de emergência.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="emergencyContactName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome do Contato de Emergência</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Digite o nome do contato de emergência"
                              {...field}
                              className="bg-gray-800 border-gray-700"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="emergencyContactPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Telefone do Contato de Emergência</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Digite o telefone do contato de emergência"
                              {...field}
                              className="bg-gray-800 border-gray-700"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="termsAccepted"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Eu aceito os termos e condições, incluindo a isenção de responsabilidade. Entendo os riscos
                          associados à participação em um evento de artes marciais.
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={isSubmitting}>
                  {isSubmitting ? "Enviando..." : "Enviar Inscrição"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
