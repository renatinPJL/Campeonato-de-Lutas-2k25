"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Trophy, Medal } from "lucide-react"

// Dados simulados para chaves do torneio
const modalities = ["Jiu-jitsu", "Judô", "Taekwondo"]

const categories = ["Infantil", "Juvenil", "Adulto", "Master"]

const weightClasses = ["Super-Leve", "Leve", "Médio", "Meio-Pesado", "Pesado", "Super-Pesado"]

// Gerar dados simulados de chaves
const generateBracketData = (numParticipants = 8) => {
  const participants = []
  for (let i = 1; i <= numParticipants; i++) {
    participants.push({
      id: i,
      name: `Participante ${i}`,
      city: [
        "São Paulo",
        "Rio de Janeiro",
        "Belo Horizonte",
        "Curitiba",
        "Brasília",
        "Salvador",
        "Fortaleza",
        "Recife",
      ][Math.floor(Math.random() * 8)],
    })
  }

  // Gerar rodadas
  const rounds = []
  let remainingParticipants = [...participants]

  while (remainingParticipants.length > 1) {
    const roundMatches = []
    const nextRoundParticipants = []

    for (let i = 0; i < remainingParticipants.length; i += 2) {
      if (i + 1 < remainingParticipants.length) {
        // Criar uma luta entre dois participantes
        const winner = Math.random() > 0.5 ? remainingParticipants[i] : remainingParticipants[i + 1]
        nextRoundParticipants.push(winner)

        roundMatches.push({
          id: `match-${rounds.length}-${i / 2}`,
          participant1: remainingParticipants[i],
          participant2: remainingParticipants[i + 1],
          winner: rounds.length === 0 ? null : winner, // Mostrar vencedores apenas para rodadas concluídas
        })
      } else {
        // Número ímpar de participantes, um recebe um bye
        nextRoundParticipants.push(remainingParticipants[i])
        roundMatches.push({
          id: `match-${rounds.length}-${i / 2}`,
          participant1: remainingParticipants[i],
          participant2: null,
          winner: rounds.length === 0 ? null : remainingParticipants[i],
        })
      }
    }

    rounds.push({
      name:
        rounds.length === 0
          ? "Quartas de Final"
          : rounds.length === 1
            ? "Semifinais"
            : rounds.length === 2
              ? "Final"
              : `Rodada ${rounds.length + 1}`,
      matches: roundMatches,
    })

    remainingParticipants = nextRoundParticipants
  }

  return rounds
}

export default function BracketsPage() {
  const [selectedModality, setSelectedModality] = useState(modalities[0])
  const [selectedCategory, setSelectedCategory] = useState(categories[2]) // Adulto por padrão
  const [selectedWeightClass, setSelectedWeightClass] = useState(weightClasses[2]) // Médio por padrão

  // Gerar dados de chaves com base nas seleções
  const bracketData = generateBracketData(8)

  return (
    <div className="container mx-auto px-4 py-12 bg-gray-950 text-gray-200">
      <div className="mb-8">
        <Link href="/" className="text-red-500 hover:text-red-400 flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Voltar para a Página Inicial
        </Link>
      </div>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Trophy className="h-6 w-6 text-red-600" />
                Chaves do Campeonato
              </CardTitle>
              <CardDescription>Veja as chaves do campeonato e programação de lutas</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <Select value={selectedModality} onValueChange={setSelectedModality}>
                <SelectTrigger className="w-[200px] bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Modalidade" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {modalities.map((modality) => (
                    <SelectItem key={modality} value={modality}>
                      {modality}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[200px] bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedWeightClass} onValueChange={setSelectedWeightClass}>
                <SelectTrigger className="w-[200px] bg-gray-800 border-gray-700">
                  <SelectValue placeholder="Peso" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {weightClasses.map((weightClass) => (
                    <SelectItem key={weightClass} value={weightClass}>
                      {weightClass}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-4">
                {selectedModality} - {selectedCategory} - {selectedWeightClass}
              </h3>

              <div className="overflow-x-auto">
                <div className="flex gap-8 min-w-[800px] p-4">
                  {bracketData.map((round, roundIndex) => (
                    <div key={round.name} className="flex-1">
                      <div className="text-center font-medium mb-4 bg-gray-800 py-2 rounded-md">{round.name}</div>
                      <div className="space-y-8">
                        {round.matches.map((match, matchIndex) => (
                          <div
                            key={match.id}
                            className="relative"
                            style={{
                              marginTop: roundIndex > 0 ? `${Math.pow(2, roundIndex) * 4}rem` : "0",
                            }}
                          >
                            <div className="border border-gray-700 rounded-md overflow-hidden">
                              <div
                                className={`p-3 ${match.winner === match.participant1 && roundIndex > 0 ? "bg-green-900" : "bg-gray-800"}`}
                              >
                                <div className="flex justify-between items-center">
                                  <div className="flex items-center gap-2">
                                    {match.winner === match.participant1 && roundIndex > 0 && (
                                      <Medal className="h-4 w-4 text-yellow-500" />
                                    )}
                                    <span>{match.participant1?.name || "BYE"}</span>
                                  </div>
                                  <span className="text-xs text-gray-400">{match.participant1?.city}</span>
                                </div>
                              </div>
                              <div className="border-t border-gray-700"></div>
                              <div
                                className={`p-3 ${match.winner === match.participant2 && roundIndex > 0 ? "bg-green-900" : "bg-gray-800"}`}
                              >
                                <div className="flex justify-between items-center">
                                  <div className="flex items-center gap-2">
                                    {match.winner === match.participant2 && roundIndex > 0 && (
                                      <Medal className="h-4 w-4 text-yellow-500" />
                                    )}
                                    <span>{match.participant2?.name || "BYE"}</span>
                                  </div>
                                  <span className="text-xs text-gray-400">{match.participant2?.city}</span>
                                </div>
                              </div>
                            </div>

                            {/* Linhas conectoras */}
                            {roundIndex < bracketData.length - 1 && (
                              <div className="absolute top-1/2 right-0 w-8 h-[2px] bg-gray-700"></div>
                            )}
                            {roundIndex > 0 && matchIndex % 2 === 0 && (
                              <div className="absolute left-[-8px] top-1/2 w-8 h-[2px] bg-gray-700"></div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8">
              <Tabs defaultValue="schedule">
                <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                  <TabsTrigger value="schedule" className="data-[state=active]:bg-gray-700">
                    Programação de Lutas
                  </TabsTrigger>
                  <TabsTrigger value="results" className="data-[state=active]:bg-gray-700">
                    Resultados
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="schedule" className="mt-4">
                  <div className="rounded-md border border-gray-800">
                    <table className="min-w-full divide-y divide-gray-800">
                      <thead className="bg-gray-800">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Horário
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Tatame
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Fase
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Luta
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-gray-900 divide-y divide-gray-800">
                        {[...Array(5)].map((_, i) => (
                          <tr key={i}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {`${9 + Math.floor(i / 2)}:${i % 2 === 0 ? "00" : "30"}`}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">{`Tatame ${(i % 3) + 1}`}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {i < 4 ? "Quartas de Final" : "Semifinais"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {`Participante ${i * 2 + 1} vs Participante ${i * 2 + 2}`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </TabsContent>
                <TabsContent value="results" className="mt-4">
                  <div className="rounded-md border border-gray-800">
                    <table className="min-w-full divide-y divide-gray-800">
                      <thead className="bg-gray-800">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Luta
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Vencedor
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Placar
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Método
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-gray-900 divide-y divide-gray-800">
                        {[...Array(3)].map((_, i) => (
                          <tr key={i}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {`Participante ${i * 2 + 1} vs Participante ${i * 2 + 2}`}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {`Participante ${i * 2 + (Math.random() > 0.5 ? 1 : 2)}`}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {`${Math.floor(Math.random() * 5)} - ${Math.floor(Math.random() * 3)}`}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {["Pontos", "Finalização", "Decisão"][Math.floor(Math.random() * 3)]}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
