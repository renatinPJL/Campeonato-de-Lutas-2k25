"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Search, Filter, Trophy } from "lucide-react"

// Dados simulados para participantes
const mockParticipants = [
  {
    id: 1,
    name: "Alexandre Silva",
    city: "São Paulo",
    modality: "Jiu-jitsu",
    category: "Adulto",
    weightClass: "Médio",
    beltRank: "Avançado",
    status: "Confirmado",
  },
  {
    id: 2,
    name: "Maria Santos",
    city: "Rio de Janeiro",
    modality: "Judô",
    category: "Adulto",
    weightClass: "Leve",
    beltRank: "Intermediário",
    status: "Confirmado",
  },
  {
    id: 3,
    name: "Carlos Oliveira",
    city: "Belo Horizonte",
    modality: "Taekwondo",
    category: "Juvenil",
    weightClass: "Meio-Pesado",
    beltRank: "Avançado",
    status: "Confirmado",
  },
  {
    id: 4,
    name: "Juliana Costa",
    city: "Curitiba",
    modality: "Jiu-jitsu",
    category: "Adulto",
    weightClass: "Leve",
    beltRank: "Intermediário",
    status: "Pendente",
  },
  {
    id: 5,
    name: "Roberto Almeida",
    city: "Brasília",
    modality: "Judô",
    category: "Master",
    weightClass: "Pesado",
    beltRank: "Expert",
    status: "Confirmado",
  },
  {
    id: 6,
    name: "Lucas Ferreira",
    city: "Salvador",
    modality: "Taekwondo",
    category: "Adulto",
    weightClass: "Médio",
    beltRank: "Iniciante",
    status: "Confirmado",
  },
  {
    id: 7,
    name: "Fernanda Lima",
    city: "Fortaleza",
    modality: "Jiu-jitsu",
    category: "Juvenil",
    weightClass: "Super-Leve",
    beltRank: "Avançado",
    status: "Pendente",
  },
  {
    id: 8,
    name: "Marcelo Souza",
    city: "Recife",
    modality: "Judô",
    category: "Adulto",
    weightClass: "Médio",
    beltRank: "Intermediário",
    status: "Confirmado",
  },
  {
    id: 9,
    name: "Camila Rodrigues",
    city: "Porto Alegre",
    modality: "Taekwondo",
    category: "Infantil",
    weightClass: "Super-Leve",
    beltRank: "Iniciante",
    status: "Confirmado",
  },
  {
    id: 10,
    name: "Paulo Mendes",
    city: "Manaus",
    modality: "Jiu-jitsu",
    category: "Master",
    weightClass: "Meio-Pesado",
    beltRank: "Expert",
    status: "Confirmado",
  },
  {
    id: 11,
    name: "Aline Cardoso",
    city: "Goiânia",
    modality: "Judô",
    category: "Adulto",
    weightClass: "Leve",
    beltRank: "Iniciante",
    status: "Pendente",
  },
  {
    id: 12,
    name: "Bruno Santos",
    city: "Belém",
    modality: "Taekwondo",
    category: "Juvenil",
    weightClass: "Médio",
    beltRank: "Intermediário",
    status: "Confirmado",
  },
]

export default function ParticipantsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [modalityFilter, setModalityFilter] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [weightClassFilter, setWeightClassFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  // Filtrar participantes com base na pesquisa e filtros
  const filteredParticipants = mockParticipants.filter((participant) => {
    const matchesSearch =
      participant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      participant.city.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesModality = modalityFilter === "all" || participant.modality === modalityFilter
    const matchesCategory = categoryFilter === "all" || participant.category === categoryFilter
    const matchesWeightClass = weightClassFilter === "all" || participant.weightClass === weightClassFilter
    const matchesStatus = statusFilter === "all" || participant.status === statusFilter

    return matchesSearch && matchesModality && matchesCategory && matchesWeightClass && matchesStatus
  })

  // Obter valores únicos para filtros
  const modalities = [...new Set(mockParticipants.map((p) => p.modality))]
  const categories = [...new Set(mockParticipants.map((p) => p.category))]
  const weightClasses = [...new Set(mockParticipants.map((p) => p.weightClass))]
  const statuses = [...new Set(mockParticipants.map((p) => p.status))]

  return (
    <div className="container mx-auto px-4 py-12 bg-gray-950 text-gray-200">
      <div className="mb-8">
        <Link href="/" className="text-red-500 hover:text-red-400 flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Voltar para a Página Inicial
        </Link>
      </div>

      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Trophy className="h-6 w-6 text-red-600" />
                Participantes do Campeonato
              </CardTitle>
              <CardDescription>Veja todos os participantes inscritos para o Campeonato de Lutas 2025</CardDescription>
            </div>
            <Button asChild className="bg-red-600 hover:bg-red-700">
              <Link href="/register">Inscreva-se Agora</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nome ou cidade..."
                  className="pl-8 bg-gray-800 border-gray-700"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground hidden sm:inline">Filtros:</span>
                </div>

                <Select value={modalityFilter} onValueChange={setModalityFilter}>
                  <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Modalidade" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="all">Todas as Modalidades</SelectItem>
                    {modalities.map((modality) => (
                      <SelectItem key={modality} value={modality}>
                        {modality}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="all">Todas as Categorias</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={weightClassFilter} onValueChange={setWeightClassFilter}>
                  <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
                    <SelectValue placeholder="Peso" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="all">Todos os Pesos</SelectItem>
                    {weightClasses.map((weightClass) => (
                      <SelectItem key={weightClass} value={weightClass}>
                        {weightClass}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="rounded-md border border-gray-800">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-800 hover:bg-gray-800/50">
                    <TableHead>Nome</TableHead>
                    <TableHead>Cidade</TableHead>
                    <TableHead>Modalidade</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Peso</TableHead>
                    <TableHead>Graduação</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredParticipants.length > 0 ? (
                    filteredParticipants.map((participant) => (
                      <TableRow key={participant.id} className="border-gray-800 hover:bg-gray-800/50">
                        <TableCell className="font-medium">{participant.name}</TableCell>
                        <TableCell>{participant.city}</TableCell>
                        <TableCell>{participant.modality}</TableCell>
                        <TableCell>{participant.category}</TableCell>
                        <TableCell>{participant.weightClass}</TableCell>
                        <TableCell>{participant.beltRank}</TableCell>
                        <TableCell>
                          <Badge
                            variant={participant.status === "Confirmado" ? "default" : "outline"}
                            className={participant.status === "Confirmado" ? "bg-green-500 hover:bg-green-600" : ""}
                          >
                            {participant.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow className="border-gray-800">
                      <TableCell colSpan={7} className="h-24 text-center">
                        Nenhum participante encontrado com os critérios selecionados.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="text-sm text-muted-foreground">
              Mostrando {filteredParticipants.length} de {mockParticipants.length} participantes
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
