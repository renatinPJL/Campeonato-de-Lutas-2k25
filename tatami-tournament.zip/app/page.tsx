import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Trophy, Users, ClipboardList, Shield } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-950 text-gray-200">
      <header className="bg-gray-900 py-6 border-b border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Trophy className="h-8 w-8 text-red-600" />
              <h1 className="text-2xl font-bold">Campeonato de Lutas 2025</h1>
            </div>
            <nav className="hidden md:flex gap-6">
              <Link href="/" className="hover:text-red-500 transition-colors">
                Início
              </Link>
              <Link href="/register" className="hover:text-red-500 transition-colors">
                Inscrição
              </Link>
              <Link href="/participants" className="hover:text-red-500 transition-colors">
                Participantes
              </Link>
              <Link href="/brackets" className="hover:text-red-500 transition-colors">
                Chaves
              </Link>
              <Link href="/admin" className="hover:text-red-500 transition-colors">
                Admin
              </Link>
            </nav>
            <Button variant="outline" className="hidden md:flex border-red-600 text-white hover:bg-red-600">
              Login
            </Button>
            <Button variant="outline" className="md:hidden border-red-600 text-white">
              Menu
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-red-700 to-gray-950 py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Campeonato de Lutas 2025</h1>
            <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto">
              Mostre sua força. Mostre sua técnica. Mostre quem você é.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
                <Link href="/register">Inscreva-se Agora</Link>
              </Button>
              <Button size="lg" variant="outline" className="border-red-600 text-white hover:bg-red-600">
                <Link href="/brackets">Ver Chaves</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Tournament Info */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Informações do Evento</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-gray-800 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
                <div className="bg-red-600 p-3 rounded-full mb-4">
                  <ClipboardList className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Detalhes do Evento</h3>
                <p className="text-gray-300">
                  Data: 20 de julho de 2025
                  <br />
                  Local: Ginásio Municipal de Esportes
                  <br />
                  Av. das Lutas, 123, Centro
                </p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
                <div className="bg-red-600 p-3 rounded-full mb-4">
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Modalidades</h3>
                <p className="text-gray-300">
                  Jiu-jitsu
                  <br />
                  Judô
                  <br />
                  Taekwondo
                </p>
              </div>
              <div className="bg-gray-800 p-6 rounded-lg shadow-md flex flex-col items-center text-center">
                <div className="bg-red-600 p-3 rounded-full mb-4">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">Categorias</h3>
                <p className="text-gray-300">
                  Infantil, Juvenil, Adulto e Master
                  <br />
                  Masculino e Feminino
                  <br />
                  Por nível e peso
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Current Registrations */}
        <section className="py-16 bg-gray-950">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold">Inscrições por Modalidade</h2>
              <Link
                href="/participants"
                className="text-red-500 hover:text-red-400 font-medium flex items-center gap-2"
              >
                <Users className="h-5 w-5" />
                Ver Todos os Participantes
              </Link>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {["Jiu-jitsu", "Judô", "Taekwondo"].map((category) => (
                <div key={category} className="bg-gray-800 p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold mb-4 pb-2 border-b border-gray-700">{category}</h3>
                  <div className="space-y-3">
                    <p className="flex justify-between">
                      <span>Total de Inscrições:</span>
                      <span className="font-semibold">{Math.floor(Math.random() * 20) + 10}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Categorias Ativas:</span>
                      <span className="font-semibold">{Math.floor(Math.random() * 8) + 3}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Média de Experiência:</span>
                      <span className="font-semibold">{Math.floor(Math.random() * 5) + 3} anos</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gray-900 py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para Competir?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Não perca a chance de participar deste prestigiado campeonato estadual. Inscreva-se hoje e prepare-se para
              o desafio!
            </p>
            <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
              <Link href="/register">Inscreva-se Agora</Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 py-8 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Campeonato de Lutas 2025</h3>
              <p className="text-gray-400">
                O principal campeonato estadual de artes marciais para lutadores de todos os níveis.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Links Rápidos</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/register" className="text-gray-400 hover:text-white">
                    Inscrição
                  </Link>
                </li>
                <li>
                  <Link href="/participants" className="text-gray-400 hover:text-white">
                    Participantes
                  </Link>
                </li>
                <li>
                  <Link href="/brackets" className="text-gray-400 hover:text-white">
                    Chaves do Torneio
                  </Link>
                </li>
                <li>
                  <Link href="/rules" className="text-gray-400 hover:text-white">
                    Regras e Regulamentos
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Contato</h3>
              <p className="text-gray-400">Email: info@campeonatodelutas.com.br</p>
              <p className="text-gray-400">Telefone: (11) 99645-1128</p>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2025 Campeonato de Lutas. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
