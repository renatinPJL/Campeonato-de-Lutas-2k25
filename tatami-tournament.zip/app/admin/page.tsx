"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Search, CheckCircle, XCircle, Edit, Trash, Download, Users, Calendar } from "lucide-react"

// Dados simulados para inscrições
const mockRegistrations = [
  {
    id: 1,
    name: "Alexandre Silva",
    email: "alexandre@exemplo.com",
    modality: "Jiu-jitsu",
    category: "Adulto",
    weightClass: "Médio",
    beltRank: "Avançado",
    registrationDate: "2025-05-10",
    status: "Pendente",
  },
  {
    id: 2,
    name: "Maria Santos",
    email: "maria@exemplo.com",
    modality: "Judô",
    category: "Adulto",
    weightClass: "Leve",
    beltRank: "Intermediário",
    registrationDate: "2025-05-11",
    status: "Aprovado",
  },
  {
    id: 3,
    name: "Carlos Oliveira",
    email: "carlos@exemplo.com",
    modality: "Taekwondo",
    category: "Juvenil",
    weightClass: "Meio-Pesado",
    beltRank: "Avançado",
    registrationDate: "2025-05-12",
    status: "Aprovado",
  },
  {
    id: 4,
    name: "Juliana Costa",
    email: "juliana@exemplo.com",
    modality: "Jiu-jitsu",
    category: "Adulto",
    weightClass: "Leve",
    beltRank: "Intermediário",
    registrationDate: "2025-05-12",
    status: "Pendente",
  },
  {
    id: 5,
    name: "Roberto Almeida",
    email: "roberto@exemplo.com",
    modality: "Judô",
    category: "Master",
    weightClass: "Pesado",
    beltRank: "Expert",
    registrationDate: "2025-05-13",
    status: "Aprovado",
  },
  {
    id: 6,
    name: "Lucas Ferreira",
    email: "lucas@exemplo.com",
    modality: "Taekwondo",
    category: "Adulto",
    weightClass: "Médio",
    beltRank: "Iniciante",
    registrationDate: "2025-05-14",
    status: "Pendente",
  },
  {
    id: 7,
    name: "Fernanda Lima",
    email: "fernanda@exemplo.com",
    modality: "Jiu-jitsu",
    category: "Juvenil",
    weightClass: "Super-Leve",
    beltRank: "Avançado",
    registrationDate: "2025-05-14",
    status: "Rejeitado",
  },
]

export default function AdminPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [registrations, setRegistrations] = useState(mockRegistrations)

  // Filtrar inscrições com base na pesquisa e filtros
  const filteredRegistrations = registrations.filter((registration) => {
    const matchesSearch =
      registration.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      registration.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || registration.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Lidar com aprovação de inscrição
  const handleApprove = (id: number) => {
    setRegistrations(registrations.map((reg) => (reg.id === id ? { ...reg, status: "Aprovado" } : reg)))
  }

  // Lidar com rejeição de inscrição
  const handleReject = (id: number) => {
    setRegistrations(registrations.map((reg) => (reg.id === id ? { ...reg, status: "Rejeitado" } : reg)))
  }

  // Estatísticas do campeonato
  const stats = {
    totalRegistrations: registrations.length,
    approvedRegistrations: registrations.filter((reg) => reg.status === "Aprovado").length,
    pendingRegistrations: registrations.filter((reg) => reg.status === "Pendente").length,
    rejectedRegistrations: registrations.filter((reg) => reg.status === "Rejeitado").length,
  }

  // Distribuição de modalidades
  const modalityDistribution = registrations.reduce(
    (acc, reg) => {
      acc[reg.modality] = (acc[reg.modality] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <div className="container mx-auto px-4 py-12 bg-gray-950 text-gray-200">
      <div className="mb-8">
        <Link href="/" className="text-red-500 hover:text-red-400 flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Voltar para a Página Inicial
        </Link>
      </div>

      <div className="grid gap-6">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-2xl">Painel de Administração do Campeonato</CardTitle>
            <CardDescription>Gerencie inscrições, chaves e configurações do campeonato</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Total de Inscrições</p>
                      <p className="text-3xl font-bold">{stats.totalRegistrations}</p>
                    </div>
                    <Users className="h-8 w-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Aprovados</p>
                      <p className="text-3xl font-bold">{stats.approvedRegistrations}</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Pendentes</p>
                      <p className="text-3xl font-bold">{stats.pendingRegistrations}</p>
                    </div>
                    <Calendar className="h-8 w-8 text-yellow-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Rejeitados</p>
                      <p className="text-3xl font-bold">{stats.rejectedRegistrations}</p>
                    </div>
                    <XCircle className="h-8 w-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="registrations">
          <TabsList className="grid w-full grid-cols-3 bg-gray-800">
            <TabsTrigger value="registrations" className="data-[state=active]:bg-gray-700">
              Inscrições
            </TabsTrigger>
            <TabsTrigger value="brackets" className="data-[state=active]:bg-gray-700">
              Chaves
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-gray-700">
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="registrations" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Gerenciamento de Inscrições</CardTitle>
                <CardDescription>Revise e aprove inscrições de participantes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Buscar por nome ou email..."
                        className="pl-8 bg-gray-800 border-gray-700"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>

                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="all">Todos os Status</SelectItem>
                        <SelectItem value="Pendente">Pendente</SelectItem>
                        <SelectItem value="Aprovado">Aprovado</SelectItem>
                        <SelectItem value="Rejeitado">Rejeitado</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button variant="outline" className="flex items-center gap-2 border-gray-700">
                      <Download className="h-4 w-4" />
                      Exportar
                    </Button>
                  </div>

                  <div className="rounded-md border border-gray-800">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-800 hover:bg-gray-800/50">
                          <TableHead>Nome</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Modalidade</TableHead>
                          <TableHead>Categoria</TableHead>
                          <TableHead>Data de Inscrição</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredRegistrations.length > 0 ? (
                          filteredRegistrations.map((registration) => (
                            <TableRow key={registration.id} className="border-gray-800 hover:bg-gray-800/50">
                              <TableCell className="font-medium">{registration.name}</TableCell>
                              <TableCell>{registration.email}</TableCell>
                              <TableCell>{registration.modality}</TableCell>
                              <TableCell>{registration.category}</TableCell>
                              <TableCell>{registration.registrationDate}</TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={
                                    registration.status === "Aprovado"
                                      ? "bg-green-900 text-green-100 hover:bg-green-900"
                                      : registration.status === "Rejeitado"
                                        ? "bg-red-900 text-red-100 hover:bg-red-900"
                                        : "bg-yellow-900 text-yellow-100 hover:bg-yellow-900"
                                  }
                                >
                                  {registration.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  {registration.status === "Pendente" && (
                                    <>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleApprove(registration.id)}
                                        className="h-8 w-8 text-green-600 hover:bg-gray-800"
                                      >
                                        <CheckCircle className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleReject(registration.id)}
                                        className="h-8 w-8 text-red-600 hover:bg-gray-800"
                                      >
                                        <XCircle className="h-4 w-4" />
                                      </Button>
                                    </>
                                  )}
                                  <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-gray-800">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-gray-800">
                                    <Trash className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow className="border-gray-800">
                            <TableCell colSpan={7} className="h-24 text-center">
                              Nenhuma inscrição encontrada com os critérios selecionados.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="brackets" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Chaves do Campeonato</CardTitle>
                <CardDescription>Gerencie e gere chaves do campeonato</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Modalidades</h3>
                      <div className="space-y-4">
                        {Object.entries(modalityDistribution).map(([modality, count]) => (
                          <div key={modality} className="flex items-center justify-between">
                            <span>{modality}</span>
                            <div className="flex items-center gap-4">
                              <span className="text-sm text-gray-400">{count} participantes</span>
                              <Button variant="outline" size="sm" className="border-gray-700 hover:bg-gray-800">
                                Gerar Chave
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium mb-4">Configurações de Chaves</h3>
                      <div className="space-y-4">
                        <div className="grid gap-2">
                          <Label htmlFor="bracket-type">Tipo de Chave</Label>
                          <Select defaultValue="single">
                            <SelectTrigger id="bracket-type" className="bg-gray-800 border-gray-700">
                              <SelectValue placeholder="Selecione o tipo de chave" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              <SelectItem value="single">Eliminação Simples</SelectItem>
                              <SelectItem value="double">Eliminação Dupla</SelectItem>
                              <SelectItem value="round-robin">Round Robin</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="seeding-method">Método de Distribuição</Label>
                          <Select defaultValue="random">
                            <SelectTrigger id="seeding-method" className="bg-gray-800 border-gray-700">
                              <SelectValue placeholder="Selecione o método de distribuição" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              <SelectItem value="random">Aleatório</SelectItem>
                              <SelectItem value="rank">Por Graduação</SelectItem>
                              <SelectItem value="manual">Manual</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch id="third-place" />
                          <Label htmlFor="third-place">Incluir disputa de terceiro lugar</Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch id="auto-advance" />
                          <Label htmlFor="auto-advance">Avançar automaticamente participantes únicos</Label>
                        </div>

                        <Button className="w-full bg-red-600 hover:bg-red-700">Gerar Todas as Chaves</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Configurações do Campeonato</CardTitle>
                <CardDescription>Configure regras e configurações do campeonato</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Configurações Gerais</h3>

                      <div className="grid gap-2">
                        <Label htmlFor="tournament-name">Nome do Campeonato</Label>
                        <Input
                          id="tournament-name"
                          defaultValue="Campeonato de Lutas 2025"
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="tournament-date">Data do Campeonato</Label>
                        <Input
                          id="tournament-date"
                          type="date"
                          defaultValue="2025-07-20"
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="registration-deadline">Prazo de Inscrição</Label>
                        <Input
                          id="registration-deadline"
                          type="date"
                          defaultValue="2025-07-10"
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="venue">Local</Label>
                        <Input
                          id="venue"
                          defaultValue="Ginásio Municipal de Esportes"
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Configurações de Luta</h3>

                      <div className="grid gap-2">
                        <Label htmlFor="match-duration">Duração da Luta (minutos)</Label>
                        <Input
                          id="match-duration"
                          type="number"
                          defaultValue="3"
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="scoring-system">Sistema de Pontuação</Label>
                        <Select defaultValue="wkf">
                          <SelectTrigger id="scoring-system" className="bg-gray-800 border-gray-700">
                            <SelectValue placeholder="Selecione o sistema de pontuação" />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            <SelectItem value="wkf">Regras WKF</SelectItem>
                            <SelectItem value="ibjjf">Regras IBJJF</SelectItem>
                            <SelectItem value="wtf">Regras WTF</SelectItem>
                            <SelectItem value="custom">Regras Personalizadas</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch id="require-protective-gear" defaultChecked />
                        <Label htmlFor="require-protective-gear">Exigir equipamento de proteção</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch id="allow-video-review" defaultChecked />
                        <Label htmlFor="allow-video-review">Permitir revisão de vídeo para disputas</Label>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notificações por Email</h3>

                    <div className="flex items-center space-x-2">
                      <Switch id="registration-confirmation" defaultChecked />
                      <Label htmlFor="registration-confirmation">Enviar emails de confirmação de inscrição</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="bracket-notifications" defaultChecked />
                      <Label htmlFor="bracket-notifications">Enviar notificações de atualização de chaves</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="match-reminders" defaultChecked />
                      <Label htmlFor="match-reminders">Enviar lembretes de lutas</Label>
                    </div>
                  </div>

                  <div className="flex justify-end gap-4">
                    <Button variant="outline" className="border-gray-700 hover:bg-gray-800">
                      Cancelar
                    </Button>
                    <Button className="bg-red-600 hover:bg-red-700">Salvar Configurações</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
